<?php
    header('Content-Type: text/html; charset=utf-8');

    //variaveis 
    $nome_escola = $_POST["escola"];
    $nome_professor = $_POST["professor"];
    $turma = $_POST["turma"];
    $materia = $_POST["materia"];
    $prova = $_POST["prova"];
    $qnt_alunos = $_POST["qnt_alunos"];
    $cont = 1;
    
    //teste se preencheu o formulario
    if(isset($_POST["escola"]) && isset($_POST["professor"])
    && isset($_POST["turma"])&& isset($_POST["materia"])
    && isset($_POST["prova"])&& isset($_POST["qnt_alunos"])){
    
    echo " <br>Nome da escola: .$nome_escola";
    echo " <br>Nome do professor: .$nome_professor";
    echo " <br>Turma: .$turma";
    echo " <br>Matéria: .$materia";
    echo " <br>Prova: .$prova";
    echo " <br>Quantidade de alunos: .$qnt_alunos";

    echo "<table>"


    while($cont<=$qnt_alunos){
        echo "<tr> <td> <br><input type='text'>";
    }
    echo "</table>"

    }
    else{
        header("location:index.html");
    }

?>
